"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const CONFIG_ERROR_CODE = 105;
const API_ERROR_CODE = 135;
const KITCHEN_SINK_CODE = 199;
class IError extends Error {
}
exports.IError = IError;
class CustodyError extends IError {
    constructor(logger, message, code, error) {
        super(message);
        this.message = message;
        this.code = code;
        // replacing the stack trace with the thrown error stack trace.
        if (error) {
            let custodyError = error;
            this.stack = custodyError.stack;
        }
        CustodyError.log(logger, this.code, this.message, this.stack);
        if (!CustodyError.SUPRESS_EXIT_CODE) {
            process.exit(this.code);
        }
    }
    static log(logger, code, message, stack) {
        let messages = message.split('\n');
        if (messages.length > 1) {
            message = messages[0];
        }
        logger.error('Error code: ' + code);
        logger.error('Error message: ' + message);
        logger.error(stack);
    }
}
CustodyError.CODE = KITCHEN_SINK_CODE;
CustodyError.SUPRESS_EXIT_CODE = false;
exports.CustodyError = CustodyError;
/**
 * Configuration file error
 */
class ConfigError extends CustodyError {
    constructor(logger, message, error) {
        super(logger, message, ConfigError.CODE, error);
    }
}
ConfigError.CODE = CONFIG_ERROR_CODE;
exports.ConfigError = ConfigError;
/**
 * API errors including network, etc.
 */
class APIError extends CustodyError {
    constructor(logger, message) {
        super(logger, message, APIError.CODE);
    }
}
APIError.CODE = API_ERROR_CODE;
APIError.ERR_MSGS = [
    'ECONNREFUSED connect ECONNREFUSED', '500 Internal Server Error',
    'Invalid token'
];
exports.APIError = APIError;
class ErrorHandler {
    static isError(errMsgs, e) {
        if (errMsgs && errMsgs.length > 0) {
            for (let errPos in errMsgs) {
                let errMsg = errMsgs[errPos];
                if (e.message && e.message.indexOf(errMsg) !== -1) {
                    return true;
                }
            }
        }
        return false;
    }
    static parseError(e) {
        if (ErrorHandler.isError(ConfigError.ERR_MSGS, e)) {
            return ConfigError.CODE;
        }
        if (ErrorHandler.isError(APIError.ERR_MSGS, e)) {
            return APIError.CODE;
        }
        return null;
    }
}
exports.ErrorHandler = ErrorHandler;
//# sourceMappingURL=exitCodes.js.map