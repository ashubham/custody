"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
const logger_1 = require("./../logger");
const controlFlow_1 = require("./../controlFlow");
const message_1 = require("./../platforms/message");
const diff_1 = require("../diff");
const q = require("q");
const method_utils_1 = require("./method-utils");
let _logger = new logger_1.Logger('test-methods');
class TestMethods {
    constructor(platform, config_) {
        this.platform = platform;
        this.config_ = config_;
        this.defaultTimeout = config_.waitTimeout;
    }
    /**
     * Posts a message to the specified/default reciever.
     *
     * This methods waits for a response from the reciever, this
     * behaviour can be turned off by setting skipWait: true in the options.
     *
     * @param message string
     * @param opts PostMessageOptions
     */
    postMessage(message, opts = {}) {
        if (opts.skipWait) {
            return this.platform.post(message, opts.skipMention, opts.reciever);
        }
        return this.platform.post(message, opts.skipMention, opts.reciever)
            .then((response) => {
            return this.waitForMessageAfterTs(response.ts);
        });
    }
    uploadFile(absPath, opts = {}) {
        if (opts.skipWait) {
            return this.platform.uploadFile(absPath, opts.comment, opts.reciever);
        }
        return this.platform.uploadFile(absPath, opts.comment, opts.reciever)
            .then((response) => {
            return this.waitForMessageAfterTs(response.ts);
        });
    }
    sleep(time = 0) {
        return q.delay(time);
    }
    getLastMessage(onlyString = false, reciever) {
        return this.platform.getLastMessage(reciever)
            .then((msg) => {
            return (onlyString) ? msg.text : msg;
        });
    }
    waitForResponseToBe(target, opts = {}) {
        let latestDelta = null;
        return method_utils_1.wait(() => {
            return this.platform.getLastMessage(opts.reciever)
                .then((message) => {
                try {
                    latestDelta = this.platform.compare(message.payload, target, opts.normalizer, opts.skipNormalization);
                    //console.log(latestDelta, message);
                }
                catch (e) {
                    _logger.error(e);
                }
                return !latestDelta;
            });
        }, `Response match ${JSON.stringify(target)}`, opts.timeout).then(null, (err) => {
            _logger.error(`FAILED\n`, latestDelta);
            if (latestDelta) {
                diff_1.default.console.log(latestDelta);
            }
            return q.reject(err);
        });
    }
    waitForFileShare(reciever, timeout) {
        return method_utils_1.wait(() => {
            return this.platform.getLastMessage(reciever).
                then((message) => {
                if (message.type === message_1.MessageTypes.FILE_SHARE) {
                    return message;
                }
            });
        }, 'File Upload', timeout);
    }
    wait(method, message, timeout) {
        return method_utils_1.wait(method, message, timeout);
    }
    waitForMessageAfterTs(timestamp, reciever) {
        return method_utils_1.wait(() => {
            return this.platform.getLastMessage(reciever).then(message => {
                return message.ts > timestamp;
            });
        }, 'Message after timestamp');
    }
}
__decorate([
    controlFlow_1.flowify
], TestMethods.prototype, "postMessage", null);
__decorate([
    controlFlow_1.flowify
], TestMethods.prototype, "uploadFile", null);
__decorate([
    controlFlow_1.flowify
], TestMethods.prototype, "sleep", null);
__decorate([
    controlFlow_1.flowify
], TestMethods.prototype, "getLastMessage", null);
__decorate([
    controlFlow_1.flowify
], TestMethods.prototype, "waitForResponseToBe", null);
__decorate([
    controlFlow_1.flowify
], TestMethods.prototype, "wait", null);
exports.TestMethods = TestMethods;
//# sourceMappingURL=testMethods.js.map