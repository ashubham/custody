import { PostMessageOptions } from './testMethods';
import { Message } from './../platforms/message';
import { Config } from './../config';
import { Platform } from '../platforms/platform';
import * as q from 'q';
/**
 * Options available when posting messages.
 *
 * @export
 * @interface PostMessageOptions
 */
export interface PostMessageOptions {
    /**
     * Do not wait for a response to the posted message.
     *
     * @type {boolean}
     * @memberOf PostMessageOptions
     */
    skipWait?: boolean;
    /**
     * Do not tag the name of the reciever in the beginning of the message.
     *
     * @type {boolean}
     * @memberOf PostMessageOptions
     */
    skipMention?: boolean;
    /**
     * The reciever id.
     *
     * @type {string}
     * @memberOf PostMessageOptions
     */
    reciever?: string;
}
export interface WaitForResponseOptions {
    /**
     * The reciever id.
     *
     * @type {string}
     * @memberOf WaitForResponseOptions
     */
    reciever?: string;
    normalizer?: (msg: any) => any;
    timeout?: number;
    skipNormalization?: boolean;
}
export interface UploadFileOptions {
    comment?: string;
    reciever?: string;
    skipWait?: boolean;
}
export declare class TestMethods {
    private platform;
    private config_;
    private defaultTimeout;
    constructor(platform: Platform, config_: Config);
    /**
     * Posts a message to the specified/default reciever.
     *
     * This methods waits for a response from the reciever, this
     * behaviour can be turned off by setting skipWait: true in the options.
     *
     * @param message string
     * @param opts PostMessageOptions
     */
    postMessage(message: string, opts?: PostMessageOptions): PromiseLike<any>;
    uploadFile(filepath: string, opts?: UploadFileOptions): PromiseLike<any>;
    sleep(time?: number): q.Promise<void>;
    getLastMessage(onlyString?: boolean, reciever?: string): PromiseLike<Message | string>;
    waitForResponseToBe(target: object | string, opts?: WaitForResponseOptions): q.Promise<{}>;
    waitForFileShare(reciever?: string, timeout?: number): q.Promise<any>;
    wait(method: (() => any | PromiseLike<any>) | PromiseLike<any>, message?: string, timeout?: number): q.Promise<any>;
    private waitForMessageAfterTs(timestamp, reciever?);
}
