"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const configParser_1 = require("./configParser");
class Task {
    constructor(config) {
        this.config = config;
        this.taskId = null;
        let excludes = configParser_1.ConfigParser.resolveFilePatterns(config.exclude, true, config.configDir);
        this.specs =
            configParser_1.ConfigParser.resolveFilePatterns(configParser_1.ConfigParser.getSpecs(config), false, config.configDir)
                .filter((path) => {
                return excludes.indexOf(path) < 0;
            });
    }
}
exports.Task = Task;
//# sourceMappingURL=task.js.map