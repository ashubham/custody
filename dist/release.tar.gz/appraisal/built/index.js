"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
Object.defineProperty(exports, 'csty', {
    get: () => global['csty']
});
//# sourceMappingURL=index.js.map