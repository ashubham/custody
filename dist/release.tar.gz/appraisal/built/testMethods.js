"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class TestMethods {
    constructor(platform) {
        this.platform = platform;
    }
    postMessage(message) {
        console.log(message);
    }
    sleep() {
    }
    getLastMesssage() {
    }
    wait() {
    }
}
exports.TestMethods = TestMethods;
//# sourceMappingURL=testMethods.js.map