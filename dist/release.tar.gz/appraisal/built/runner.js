"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const testMethods_1 = require("./methods/testMethods");
const events_1 = require("events");
const q = require("q");
const logger_1 = require("./logger");
const helper = require("./util");
const platforms = require("./platforms/platforms");
let logger = new logger_1.Logger('runner');
/*
 * Runner is responsible for starting the execution of a test run and triggering
 * setup, teardown, managing config, etc through its various dependencies.
 *
 * The Custody Runner is a node EventEmitter with the following events:
 * - testPass
 * - testFail
 * - testsDone
 *
 * @param {Object} config
 * @constructor
 */
class Runner extends events_1.EventEmitter {
    constructor(config, task) {
        super();
        this.task = task;
        /**
         * Responsible for cleaning up test run and exiting the process.
         * @private
         * @param {int} Standard unix exit code
         */
        this.exit_ = function (exitCode) {
            return helper.runFilenameOrFn_(this.config_.configDir, this.config_.onCleanUp, [exitCode])
                .then((returned) => {
                if (typeof returned === 'number') {
                    return returned;
                }
                else {
                    return exitCode;
                }
            });
        };
        this.config_ = config;
        this.setTestPreparer(config.onPrepare);
    }
    /**
     * Registrar for testPreparers - executed right before tests run.
     * @public
     * @param {string/Fn} filenameOrFn
     */
    setTestPreparer(filenameOrFn) {
        this.preparer_ = filenameOrFn;
    }
    /**
     * Executor of testPreparer
     * @public
     * @param {string[]=} An optional list of command line arguments the framework will accept.
     * @return {q.Promise} A promise that will resolve when the test preparers
     *     are finished.
     */
    runTestPreparer(extraFlags) {
        let unknownFlags = this.config_.unknownFlags_ || [];
        if (extraFlags) {
            unknownFlags = unknownFlags.filter((f) => extraFlags.indexOf(f) === -1);
        }
        if (unknownFlags.length > 0 && !this.config_.disableChecks) {
            // TODO: Make this throw a ConfigError in Custody 6.
            logger.warn('Ignoring unknown extra flags: ' + unknownFlags.join(', ') + '. This will be' +
                ' an error in future versions, please use --disableChecks flag to disable the ' +
                ' Custody CLI flag checks. ');
        }
        return helper.runFilenameOrFn_(this.config_.configDir, this.preparer_);
    }
    /**
     * Getter for the Runner config object
     * @public
     * @return {Object} config
     */
    getConfig() {
        return this.config_;
    }
    getPlatform() {
        return platforms.getPlatform(this.config_);
    }
    /**
     * Sets up convenience globals for test specs
     * @param platform
     */
    setupGlobals(platform) {
        let testMethods = new testMethods_1.TestMethods(platform, this.config_);
        if (this.config_.defaultRecipient) {
            platform.defaultRecipient = this.config_.defaultRecipient;
        }
        if (this.config_.botId) {
            platform.defaultMention = this.config_.botId;
        }
        global.csty = testMethods;
    }
    run() {
        let testPassed;
        let results;
        this.config_.specs = this.task.specs;
        return q.resolve(null)
            .then(() => {
            let platform = this.getPlatform();
            return platform.auth();
        })
            .then(this.setupGlobals.bind(this))
            .then(() => {
            // Do the framework setup here so that jasmine and mocha globals are
            // available to the onPrepare function.
            let frameworkPath = '';
            if (this.config_.framework === 'jasmine' || this.config_.framework === 'jasmine2') {
                frameworkPath = './frameworks/jasmine.js';
            }
            else if (this.config_.framework === 'mocha') {
                frameworkPath = './frameworks/mocha.js';
            }
            else if (this.config_.framework === 'custom') {
                if (!this.config_.frameworkPath) {
                    throw new Error('When config.framework is custom, ' +
                        'config.frameworkPath is required.');
                }
                frameworkPath = this.config_.frameworkPath;
            }
            else {
                throw new Error('config.framework (' + this.config_.framework + ') is not a valid framework.');
            }
            logger.debug('Running with spec files ' + this.config_.specs);
            return require(frameworkPath).run(this, this.config_.specs);
        })
            .then((results) => {
            results.taskId = this.task.taskId;
            results.specs = this.task.specs;
            testPassed = results.failedCount === 0;
            let exitCode = testPassed ? 0 : 1;
            results.exitCode = exitCode;
            this.emit('testsDone', results);
            return this.exit_(exitCode);
        });
    }
}
exports.Runner = Runner;
//# sourceMappingURL=runner.js.map