declare function sleep(): void;
declare function getLastMesssage(): void;
declare function wait(): void;
