/**
 * Keeps track of a list of task results. Provides method to add a new
 * result, aggregate the results into a summary, count failures,
 * and save results into a JSON file.
 */
export declare class TaskResults {
    results_: any[];
    add(result: any): void;
    totalSpecFailures(): number;
    saveResults(filepath: string): void;
    reportSummary(): void;
}
