import { Platform } from './platforms/platform';
export declare class TestMethods {
    private platform;
    constructor(platform: Platform);
    postMessage(message: any): void;
    sleep(): void;
    getLastMesssage(): void;
    wait(): void;
}
