/// <reference types="node" />
import { Task } from './task';
import { Platform } from './platforms/platform';
import { EventEmitter } from 'events';
import * as q from 'q';
import { Config } from './config';
export interface RunResults {
    taskId: number;
    specs: Array<string>;
    failedCount: number;
    exitCode: number;
    specResults: Array<any>;
}
export declare class Runner extends EventEmitter {
    private task;
    config_: Config;
    preparer_: any;
    frameworkUsesAfterEach: boolean;
    constructor(config: Config, task: Task);
    /**
     * Registrar for testPreparers - executed right before tests run.
     * @public
     * @param {string/Fn} filenameOrFn
     */
    setTestPreparer(filenameOrFn: string | Function): void;
    /**
     * Executor of testPreparer
     * @public
     * @param {string[]=} An optional list of command line arguments the framework will accept.
     * @return {q.Promise} A promise that will resolve when the test preparers
     *     are finished.
     */
    runTestPreparer(extraFlags?: string[]): q.Promise<any>;
    /**
     * Responsible for cleaning up test run and exiting the process.
     * @private
     * @param {int} Standard unix exit code
     */
    exit_: (exitCode: number) => any;
    /**
     * Getter for the Runner config object
     * @public
     * @return {Object} config
     */
    getConfig(): Config;
    getPlatform(): Platform;
    /**
     * Sets up convenience globals for test specs
     * @param platform
     */
    setupGlobals(platform: Platform): void;
    run(): q.Promise<any>;
}
