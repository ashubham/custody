declare let commandChain: Promise<void>;
declare function enqueue(command: (value?) => void | PromiseLike<any>): Promise<void>;
