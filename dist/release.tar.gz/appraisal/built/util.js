"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const path_1 = require("path");
const q_1 = require("q");
/**
 * Internal helper for abstraction of polymorphic filenameOrFn properties.
 * @param {object} filenameOrFn The filename or function that we will execute.
 * @param {Array.<object>}} args The args to pass into filenameOrFn.
 * @return {q.Promise} A promise that will resolve when filenameOrFn completes.
 */
function runFilenameOrFn_(configDir, filenameOrFn, args) {
    return q_1.Promise((resolvePromise) => {
        if (filenameOrFn && !(typeof filenameOrFn === 'string' || typeof filenameOrFn === 'function')) {
            throw new Error('filenameOrFn must be a string or function');
        }
        if (typeof filenameOrFn === 'string') {
            filenameOrFn = require(path_1.resolve(configDir, filenameOrFn));
        }
        if (typeof filenameOrFn === 'function') {
            let results = q_1.when(filenameOrFn.apply(null, args), null, (err) => {
                if (typeof err === 'string') {
                    err = new Error(err);
                }
                else {
                    err = err;
                    if (!err.stack) {
                        err.stack = new Error().stack;
                    }
                }
                err.stack = exports.filterStackTrace(err.stack);
                throw err;
            });
            resolvePromise(results);
        }
        else {
            resolvePromise(undefined);
        }
    });
}
exports.runFilenameOrFn_ = runFilenameOrFn_;
function promisify(target, pKey, descriptor) {
    descriptor = descriptor || Object.getOwnPropertyDescriptor(target, pKey);
    let originalMethod = descriptor.value;
    descriptor.value = function () {
        let deferred = q_1.defer();
        let args = [...arguments, (err, response) => {
                if (err) {
                    return deferred.reject(err);
                }
                return deferred.resolve(response);
            }];
        return originalMethod(...args);
    };
    return descriptor;
}
exports.promisify = promisify;
//# sourceMappingURL=util.js.map