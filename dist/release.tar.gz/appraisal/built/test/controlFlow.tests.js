"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const chai_1 = require("chai");
const controlFlow_1 = require("../lib/controlFlow");
describe('Control flow', function () {
    it('constructor', () => {
        let cf = new controlFlow_1.ControlFlow();
        chai_1.expect(cf instanceof controlFlow_1.ControlFlow).to.be.true;
    });
});
//# sourceMappingURL=controlFlow.tests.js.map