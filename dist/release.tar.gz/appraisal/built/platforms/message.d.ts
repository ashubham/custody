export interface Message {
    ts: number | string;
    text: string;
    payload: any;
    type: MessageTypes;
}
export declare enum MessageTypes {
    None = 0,
    FILE_SHARE = 1,
    TEXT = 2,
}
