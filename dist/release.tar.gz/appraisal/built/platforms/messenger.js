"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const message_1 = require("./message");
const platform_1 = require("./platform");
const login = require("facebook-chat-api");
const logger_1 = require("./../logger");
const q = require("q");
const fs = require("fs");
const normalizers_1 = require("./normalizers");
let logger = new logger_1.Logger('Messenger');
class MessengerMessage {
    constructor(_payload) {
        this._payload = _payload;
    }
    get payload() {
        return this._payload;
    }
    get ts() {
        return this._payload.timestamp;
    }
    get text() {
        return this._payload.body;
    }
    get type() {
        if (this._payload.attachments.length) {
            return message_1.MessageTypes.FILE_SHARE;
        }
        return message_1.MessageTypes.TEXT;
    }
}
exports.MessengerMessage = MessengerMessage;
class Messenger extends platform_1.Platform {
    constructor(email, password) {
        super();
        this.email = email;
        this.password = password;
        logger.info('Using Messenger Platform');
    }
    auth() {
        let deferred = q.defer();
        login({ email: this.email, password: this.password }, (err, api) => {
            if (err) {
                return deferred.reject(this);
            }
            this.client = api;
            deferred.resolve(this);
        });
        return deferred.promise;
    }
    post(message, skipMention = true, recipient = this.defaultRecipient) {
        let deferred = q.defer();
        this.client.sendMessage(message, recipient, (err, resp) => {
            if (err) {
                logger.error(err);
                return deferred.reject(err);
            }
            return deferred.resolve(new MessengerMessage(resp));
        });
        return deferred.promise;
    }
    uploadFile(absPath, comment = '', reciever = this.defaultRecipient) {
        let message = {
            attachment: fs.createReadStream(absPath),
            body: comment
        };
        return q.ninvoke(this.client.files, 'sendMessage', message)
            .then(resp => new MessengerMessage(resp));
    }
    getLastMessage(recipient = this.defaultRecipient) {
        let deferred = q.defer();
        this.client.getThreadHistory(recipient, 0, 1, undefined, (err, msgs) => {
            if (err) {
                logger.debug(err);
                return deferred.reject(err);
            }
            let msg = new MessengerMessage(msgs[0]);
            return deferred.resolve(msg);
        });
        return deferred.promise;
    }
    createNormalizers() {
        let keyDel = normalizers_1.createKeyDeleteNormalizer('type', 'senderName', 'timestamp', 'senderID', 'participantNames', 'participantIDs', 'threadID', 'threadName', 'messageID', 'timestampAbsolute', 'timestampRelative', 'timestampDatetime', 'tags', 'isGroup');
        let renameKey = normalizers_1.createRenameKeyNormalizer({
            body: 'text'
        });
        let compact = normalizers_1.createDeleteNullUndefinedNormalizer();
        let addKey = normalizers_1.createAddKeyNormalizer({ attachments: [] });
        this.normalizers.push(keyDel, renameKey, compact, addKey);
    }
}
exports.Messenger = Messenger;
//# sourceMappingURL=messenger.js.map