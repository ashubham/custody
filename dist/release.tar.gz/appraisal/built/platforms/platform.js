"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const message_1 = require("./message");
const logger_1 = require("./../logger");
const diff_1 = require("../diff");
const q = require("q");
let logger = new logger_1.Logger('Platform');
var GroupTypes;
(function (GroupTypes) {
    GroupTypes[GroupTypes["None"] = 0] = "None";
    GroupTypes[GroupTypes["PUBLIC"] = 1] = "PUBLIC";
    GroupTypes[GroupTypes["PRIVATE"] = 2] = "PRIVATE";
    GroupTypes[GroupTypes["PERSONAL"] = 3] = "PERSONAL";
})(GroupTypes = exports.GroupTypes || (exports.GroupTypes = {}));
class Platform {
    constructor(...args) {
        this.normalizers = [];
        this.messageTypes = {
            FILE_SHARE: 'file_share'
        };
        this.createNormalizers();
    }
    auth() {
        return q.resolve(this);
    }
    normalize(inputObj, additionalNormalizer) {
        this.normalizers.forEach(normalizer => {
            inputObj = normalizer(inputObj);
        });
        if (additionalNormalizer) {
            return additionalNormalizer(inputObj);
        }
        return inputObj;
    }
    normalizeTarget(target) {
        if (typeof target === 'string' || typeof target === 'number') {
            target = {
                text: target.toString()
            };
        }
        target.text = target.text || '';
        target.attachments = target.attachments || [];
        return target;
    }
    compare(src, target, additionalNormalizer, skipNormalize) {
        let normalizedSrc = this.normalize(src, additionalNormalizer);
        target = this.normalizeTarget(target);
        return diff_1.default.diff(normalizedSrc, target);
    }
    getMessageType(message) {
        logger.warn('Not implemented');
        return message_1.MessageTypes.None;
    }
    //TODO(Ashish): Support Emojis/URL.    
    post(message, skipMention, reciever) {
        logger.warn('Method not implemented');
        return q.reject('Post: Method not implemented');
    }
    uploadFile(absPath, comment, reciever) {
        logger.warn('Method not implemented');
        return q.reject('Post: Method not implemented');
    }
    getLastMessage(group) {
        logger.warn('Method not implemented');
        return q.reject('getLastMessage: Method not implemented');
    }
    createNormalizers() {
        logger.warn('Method not implemented');
    }
}
exports.Platform = Platform;
//# sourceMappingURL=platform.js.map