import { Config } from '../config';
import { Platform } from './platform';
export declare function getPlatform(config: Config): Platform;
