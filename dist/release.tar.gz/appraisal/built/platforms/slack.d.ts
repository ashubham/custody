import { Message, MessageTypes } from './message';
import { Platform, GroupTypes } from './platform';
export declare class SlackMessage implements Message {
    private _payload;
    static slackMessageTypeToMessageTypes: {
        'file_share': MessageTypes;
    };
    constructor(_payload: any);
    readonly payload: any;
    readonly ts: any;
    readonly text: any;
    readonly type: MessageTypes;
}
export declare class Slack extends Platform {
    private client;
    static prefixToGroupTypes: {
        D: GroupTypes;
        U: GroupTypes;
        G: GroupTypes;
        C: GroupTypes;
    };
    static groupTypeToAPIMethod: {
        [x: number]: string;
    };
    constructor(token: string);
    post(message: string, skipMention?: boolean, group?: string): PromiseLike<any>;
    uploadFile(absPath: string, comment?: string, reciever?: string): Promise<Object>;
    getLastMessage(channel?: string): PromiseLike<SlackMessage>;
    getGroupType(group: string): any;
    protected createNormalizers(): void;
}
