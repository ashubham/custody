"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const message_1 = require("./message");
const logger_1 = require("./../logger");
const client_1 = require("@slack/client");
const normalizers_1 = require("./normalizers");
const platform_1 = require("./platform");
const q = require("q");
const path = require("path");
const fs = require("fs");
let logger = new logger_1.Logger('slack');
class SlackMessage {
    constructor(_payload) {
        this._payload = _payload;
    }
    get payload() {
        return this._payload;
    }
    get ts() {
        return this._payload.ts;
    }
    get text() {
        return this._payload.text;
    }
    get type() {
        let msgType = [this.payload.type, this.payload.subtype].join('|');
        return SlackMessage.slackMessageTypeToMessageTypes[msgType];
    }
}
SlackMessage.slackMessageTypeToMessageTypes = {
    'file_share': message_1.MessageTypes.FILE_SHARE
};
exports.SlackMessage = SlackMessage;
class Slack extends platform_1.Platform {
    constructor(token) {
        super();
        logger.info('Using Slack Platform');
        this.client = new client_1.WebClient(token);
    }
    post(message, skipMention, group) {
        let channel = group || this.defaultRecipient;
        return this.client.chat.postMessage(channel, message, {
            as_user: true
        })
            .then(response => {
            return new SlackMessage(response.message);
        })
            .catch(err => {
            logger.debug(err);
            return q.reject(err);
        });
    }
    uploadFile(absPath, comment, receiver = this.defaultRecipient) {
        let filename = path.basename(absPath);
        let file = fs.createReadStream(absPath);
        return this.client.files.upload(filename, {
            file: file,
            initial_comment: comment,
            channels: receiver
        });
    }
    getLastMessage(channel = this.defaultRecipient) {
        let groupType = this.getGroupType(channel);
        let apiMethod = Slack.groupTypeToAPIMethod[groupType];
        return this.client[apiMethod].history(channel, {
            count: 1
        }).then(response => {
            return new SlackMessage(response.messages[0]);
        }, err => {
            logger.error(err.stack);
        });
    }
    getGroupType(group) {
        let prefix = group.match(/^G|C|D|U/)[0];
        return Slack.prefixToGroupTypes[prefix];
    }
    createNormalizers() {
        let keyDel = normalizers_1.createKeyDeleteNormalizer('type', 'user', 'ts', 'subtype');
        let addKey = normalizers_1.createAddKeyNormalizer({ attachments: [] });
        this.normalizers.push(keyDel, addKey);
    }
}
Slack.prefixToGroupTypes = {
    D: platform_1.GroupTypes.PERSONAL,
    U: platform_1.GroupTypes.PERSONAL,
    G: platform_1.GroupTypes.PRIVATE,
    C: platform_1.GroupTypes.PUBLIC
};
Slack.groupTypeToAPIMethod = {
    [platform_1.GroupTypes.PERSONAL]: 'im',
    [platform_1.GroupTypes.PRIVATE]: 'groups',
    [platform_1.GroupTypes.PUBLIC]: 'channels'
};
exports.Slack = Slack;
//# sourceMappingURL=slack.js.map