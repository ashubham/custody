"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var MessageTypes;
(function (MessageTypes) {
    MessageTypes[MessageTypes["None"] = 0] = "None";
    MessageTypes[MessageTypes["FILE_SHARE"] = 1] = "FILE_SHARE";
    MessageTypes[MessageTypes["TEXT"] = 2] = "TEXT";
})(MessageTypes = exports.MessageTypes || (exports.MessageTypes = {}));
//# sourceMappingURL=message.js.map