import { Message, MessageTypes } from './message';
import { Platform } from './platform';
export declare class MessengerMessage implements Message {
    private _payload;
    constructor(_payload: any);
    readonly payload: any;
    readonly ts: any;
    readonly text: any;
    readonly type: MessageTypes;
}
export declare class Messenger extends Platform {
    private email;
    private password;
    private client;
    constructor(email: string, password: string);
    auth(): PromiseLike<Platform>;
    post(message: string, skipMention?: boolean, recipient?: string): PromiseLike<any>;
    uploadFile(absPath: string, comment?: string, reciever?: string): PromiseLike<any>;
    getLastMessage(recipient?: string): PromiseLike<MessengerMessage>;
    protected createNormalizers(): void;
}
