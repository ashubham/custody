"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const _ = require("lodash");
function createKeyDeleteNormalizer(...keys) {
    return function (inputObj) {
        return _.omit(inputObj, keys);
    };
}
exports.createKeyDeleteNormalizer = createKeyDeleteNormalizer;
function createRenameKeyNormalizer(renameMap) {
    return function (inputObj) {
        return _.mapKeys(inputObj, (value, key) => {
            return renameMap[key] || key;
        });
    };
}
exports.createRenameKeyNormalizer = createRenameKeyNormalizer;
function createDeleteNullUndefinedNormalizer() {
    return function (inputObj) {
        let copy = Object.assign({}, inputObj);
        _.each(inputObj, (v, k) => {
            if (v === undefined || v === null) {
                delete copy[k];
            }
        });
        return copy;
    };
}
exports.createDeleteNullUndefinedNormalizer = createDeleteNullUndefinedNormalizer;
function createAddKeyNormalizer(addKeyMap) {
    return function (inputObj) {
        return Object.assign({}, addKeyMap, inputObj);
    };
}
exports.createAddKeyNormalizer = createAddKeyNormalizer;
//# sourceMappingURL=normalizers.js.map