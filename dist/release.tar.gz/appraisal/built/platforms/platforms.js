"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const config_1 = require("../config");
const logger_1 = require("./../logger");
const slack_1 = require("./slack");
const messenger_1 = require("./messenger");
let logger = new logger_1.Logger('getPlatform');
const platformToPlatformClass = {
    [config_1.SupportedPlatforms.MESSENGER]: {
        ctor: messenger_1.Messenger,
        args: ['email', 'password']
    },
    [config_1.SupportedPlatforms.SLACK]: {
        ctor: slack_1.Slack,
        args: ['token']
    }
};
function getPlatform(config) {
    let platformName = config.platform;
    let platform = platformToPlatformClass[platformName];
    if (platform) {
        let args = platform.args.map(arg => config[arg]);
        return new platform.ctor(...args);
    }
    else {
        logger.error("Unsupported Platform", platformName);
    }
    return null;
}
exports.getPlatform = getPlatform;
//# sourceMappingURL=platforms.js.map