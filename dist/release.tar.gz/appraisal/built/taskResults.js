"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const logger_1 = require("./logger");
let logger = new logger_1.Logger('task-results');
/**
 * Keeps track of a list of task results. Provides method to add a new
 * result, aggregate the results into a summary, count failures,
 * and save results into a JSON file.
 */
class TaskResults {
    constructor() {
        // TODO: set a type for result
        this.results_ = [];
    }
    add(result) {
        this.results_.push(result);
    }
    totalSpecFailures() {
        return this.results_.reduce((specFailures, result) => {
            return specFailures + result.failedCount;
        }, 0);
    }
    saveResults(filepath) {
        let jsonOutput = this.results_.reduce((jsonOutput, result) => {
            return jsonOutput.concat(result.specResults);
        }, []);
        let json = JSON.stringify(jsonOutput, null, '  ');
        fs.writeFileSync(filepath, json);
    }
    reportSummary() {
        let specFailures = this.totalSpecFailures();
        this.results_.forEach((result) => {
            let shortName = [
                result.platformName,
                result.tasId
            ].join('#');
            if (result.failedCount) {
                logger.info(shortName + ' failed ' + result.failedCount + ' test(s)');
            }
            else if (result.exitCode !== 0) {
                logger.info(shortName + ' failed with exit code: ' + result.exitCode);
            }
            else {
                logger.info(shortName + ' passed');
            }
        });
        if (specFailures) {
            logger.info('overall: ' + specFailures + ' failed spec(s)');
        }
    }
}
exports.TaskResults = TaskResults;
//# sourceMappingURL=taskResults.js.map