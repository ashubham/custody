declare let diff: any;
export default diff;
