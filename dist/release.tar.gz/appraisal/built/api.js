function postMessage() {
}
function sleep() {
}
function getLastMesssage() {
}
function wait() {
}
module.exports = {
    postMessage,
    sleep,
    getLastMesssage,
    wait
};
//# sourceMappingURL=api.js.map