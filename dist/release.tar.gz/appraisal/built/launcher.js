"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const configParser_1 = require("./configParser");
const exitCodes_1 = require("./exitCodes");
const logger_1 = require("./logger");
const runner_1 = require("./runner");
const taskResults_1 = require("./taskResults");
const task_1 = require("./task");
const util = require("./util");
let logger = new logger_1.Logger('launcher');
let RUNNERS_FAILED_EXIT_CODE = 100;
process.on('uncaughtException', (exc) => {
    let e = (exc instanceof Error) ? exc : new Error(exc);
    let errorCode = exitCodes_1.ErrorHandler.parseError(e);
    if (errorCode) {
        let custodyError = e;
        exitCodes_1.CustodyError.log(logger, errorCode, custodyError.message, custodyError.stack);
        process.exit(errorCode);
    }
    else {
        logger.error(e.message);
        logger.error(e.stack);
        process.exit(exitCodes_1.CustodyError.CODE);
    }
});
process.on('exit', (code) => {
    if (code) {
        logger.error('Process exited with error code ' + code);
    }
});
// Run afterlaunch and exit
let cleanUpAndExit = (config, exitCode) => {
    return util.runFilenameOrFn_(config.configDir, config.afterLaunch, [exitCode])
        .then((returned) => {
        if (typeof returned === 'number') {
            process.exit(returned);
        }
        else {
            process.exit(exitCode);
        }
    }, (err) => {
        logger.error('Error:', err);
        process.exit(1);
    });
};
let taskResults_ = new taskResults_1.TaskResults();
/**
 * Initialize and run the tests.
 * Exits with 1 on test failure, and RUNNERS_FAILED_EXIT_CODE on unexpected
 * failures.
 *
 * @param {string=} configFile
 * @param {Object=} additionalConfig
 */
let initFn = function (configFile, additionalConfig) {
    let configParser = new configParser_1.ConfigParser();
    if (configFile) {
        configParser.addFileConfig(configFile);
    }
    if (additionalConfig) {
        configParser.addConfig(additionalConfig);
    }
    let config = configParser.getConfig();
    logger_1.Logger.set(config);
    logger.debug('Running with --troubleshoot');
    logger.debug('Custody version: ' + require('../package.json').version);
    // Run beforeLaunch
    util.runFilenameOrFn_(config.configDir, config.beforeLaunch)
        .then(() => {
        let task = new task_1.Task(config);
        let taskRunner = new runner_1.Runner(config, task);
        taskRunner.run()
            .then((result) => {
            if (result.exitCode && !result.failedCount) {
                logger.error('Runner process exited unexpectedly with error code: ' + result.exitCode);
            }
            taskResults_.add(result);
        })
            .then(function () {
            // Save results if desired
            if (config.resultJsonOutputFile) {
                taskResults_.saveResults(config.resultJsonOutputFile);
            }
            taskResults_.reportSummary();
            let exitCode = (taskResults_.totalSpecFailures() > 0)
                ? 1 : 0;
            cleanUpAndExit(config, exitCode);
        })
            .catch((err) => {
            logger.error('Error:', err.stack || err.message || err);
        })
            .done();
    })
        .done();
};
exports.init = initFn;
//# sourceMappingURL=launcher.js.map