let commandChain = Promise.resolve();
function enqueue(command) {
    return commandChain.then(command);
}
//# sourceMappingURL=control-queue.js.map