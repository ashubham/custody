"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const logger_1 = require("./logger");
const events_1 = require("events");
const Q = require("q");
let logger = new logger_1.Logger('Control-Flow');
class ControlFlow extends events_1.EventEmitter {
    constructor() {
        super();
        this.commandChain = Q.when(null);
        this.numTasks = 0;
        this._isIdle = false;
        this.promise = Q.Promise;
    }
    execute(fn, text) {
        this.numTasks++;
        this._isIdle = false;
        return this.commandChain = this.commandChain
            .then(fn)
            .then((value) => {
            if (--this.numTasks === 0) {
                this.emit('idle');
                this._isIdle = true;
            }
            return null;
        }, err => {
            logger.debug('FAILED: ERROR OCCURRED');
            if (typeof fail === 'function') {
                fail(err);
            }
            else {
                logger.error(err);
            }
            this.emit('idle');
            this._isIdle = true;
            return Q.reject(err);
        });
    }
    reset() {
        this.commandChain = Q.resolve(null);
    }
    isIdle() {
        return this._isIdle;
    }
}
exports.ControlFlow = ControlFlow;
exports.controlFlow = new ControlFlow();
function flowify(target, pKey, descriptor) {
    descriptor = descriptor || Object.getOwnPropertyDescriptor(target, pKey);
    let originalMethod = descriptor.value;
    descriptor.value = function () {
        let args = Array.prototype.slice.call(arguments);
        return exports.controlFlow.execute(originalMethod.bind(this, ...args));
    };
    return descriptor;
}
exports.flowify = flowify;
//# sourceMappingURL=controlFlow.js.map