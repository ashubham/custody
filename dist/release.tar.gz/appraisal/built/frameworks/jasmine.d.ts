/**
 * Execute the Runner's test cases through Jasmine.
 *
 * @param {Runner} runner The current Custody Runner.
 * @param {Array} specs Array of Directory Path Strings.
 * @return {q.Promise} Promise resolved with the test results
 */
export declare function run(runner: any, specs: any): any;
