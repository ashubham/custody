"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SupportedPlatforms;
(function (SupportedPlatforms) {
    SupportedPlatforms[SupportedPlatforms["None"] = 0] = "None";
    SupportedPlatforms[SupportedPlatforms["SLACK"] = 1] = "SLACK";
    SupportedPlatforms[SupportedPlatforms["MESSENGER"] = 2] = "MESSENGER";
})(SupportedPlatforms = exports.SupportedPlatforms || (exports.SupportedPlatforms = {}));
exports.platformNameToPlatform = {
    slack: SupportedPlatforms.SLACK,
    messenger: SupportedPlatforms.MESSENGER
};
//# sourceMappingURL=config.js.map