import { Logger } from './logger';
export declare class IError extends Error {
    code?: number;
    stack?: string;
}
export declare class CustodyError extends IError {
    static ERR_MSGS: string[];
    static CODE: number;
    static SUPRESS_EXIT_CODE: boolean;
    message: string;
    constructor(logger: Logger, message: string, code: number, error?: Error);
    static log(logger: Logger, code: number, message: string, stack: string): void;
}
/**
 * Configuration file error
 */
export declare class ConfigError extends CustodyError {
    static CODE: number;
    constructor(logger: Logger, message: string, error?: Error);
}
/**
 * API errors including network, etc.
 */
export declare class APIError extends CustodyError {
    static CODE: number;
    static ERR_MSGS: string[];
    constructor(logger: Logger, message: string);
}
export declare class ErrorHandler {
    static isError(errMsgs: string[], e: Error): boolean;
    static parseError(e: Error): number;
}
