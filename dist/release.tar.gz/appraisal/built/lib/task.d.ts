import { Config } from './config';
export declare class Task {
    private config;
    specs: string[];
    taskId: number;
    constructor(config: Config);
}
