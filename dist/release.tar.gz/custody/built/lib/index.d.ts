import { TestMethods } from './methods/testMethods';
export declare let csty: TestMethods;
