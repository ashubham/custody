import { GroupTypes, Platform } from './platform';
import { Message, MessageTypes } from './message';
export declare class SlackMessage implements Message {
    private _payload;
    static slackMessageTypeToMessageTypes: {
        'file_share': MessageTypes;
    };
    constructor(_payload: any);
    readonly payload: any;
    readonly ts: any;
    readonly text: any;
    readonly type: MessageTypes;
}
export declare class Slack extends Platform {
    private token;
    private client;
    static prefixToGroupTypes: {
        D: GroupTypes;
        U: GroupTypes;
        G: GroupTypes;
        C: GroupTypes;
    };
    static groupTypeToAPIMethod: {
        [x: number]: string;
    };
    constructor(token: string);
    auth(): PromiseLike<any>;
    post(message: string, skipMention?: boolean, group?: string): PromiseLike<any>;
    uploadFile(absPath: string, comment?: string, receiver?: string): Promise<Object>;
    getLastMessage(channel?: string): PromiseLike<SlackMessage>;
    getGroupType(group: string): any;
    protected createNormalizers(): void;
}
