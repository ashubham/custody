import * as _ from 'lodash';
export declare function createKeyDeleteNormalizer(...keys: any[]): (inputObj: any) => _.Dictionary<{}>;
export declare function createRenameKeyNormalizer(renameMap: {
    [key: string]: string;
}): (inputObj: any) => _.Dictionary<{}>;
export declare function createDeleteNullUndefinedNormalizer(): (inputObj: any) => any;
export declare function createAddKeyNormalizer(addKeyMap: {
    [key: string]: any;
}): (inputObj: any) => any;
