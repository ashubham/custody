import { Message, MessageTypes } from './message';
export declare enum GroupTypes {
    None = 0,
    PUBLIC = 1,
    PRIVATE = 2,
    PERSONAL = 3,
}
export declare class Platform {
    protected normalizers: any[];
    protected messageTypes: {
        FILE_SHARE: string;
    };
    defaultRecipient: string;
    defaultMention: string;
    constructor(...args: any[]);
    auth(): PromiseLike<Platform>;
    normalize(inputObj: any, additionalNormalizer?: (msg: any) => any): any;
    normalizeTarget(target: string | any): Object;
    compare(src: any, target: string | object, additionalNormalizer?: (msg: any) => any, skipNormalize?: boolean): any;
    getMessageType(message: any): MessageTypes;
    post(message: string, skipMention?: boolean, receiver?: string): PromiseLike<any>;
    uploadFile(absPath: string, comment?: string, receiver?: string): PromiseLike<any>;
    getLastMessage(group?: string): PromiseLike<Message>;
    protected createNormalizers(): void;
}
