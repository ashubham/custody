/// <reference types="node" />
import * as q from 'q';
import { EventEmitter } from 'events';
export declare class ControlFlow extends EventEmitter {
    private commandChain;
    private numTasks;
    private _isIdle;
    constructor();
    execute(fn: () => PromiseLike<any> | any, text?: string): PromiseLike<any>;
    promise: typeof q.Promise;
    reset(): void;
    isIdle(): boolean;
}
export declare let controlFlow: ControlFlow;
export declare function flowify(target: Object, pKey: string, descriptor: PropertyDescriptor): PropertyDescriptor;
