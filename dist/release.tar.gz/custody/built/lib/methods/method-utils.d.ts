export declare function wait(method: (() => any | PromiseLike<any>) | PromiseLike<any>, message?: string, timeout?: number): Q.Promise<any>;
