import * as q from 'q';
import { Config } from './../config';
import { Message } from './../platforms/message';
import { Platform } from '../platforms/platform';
import { PostMessageOptions } from './testMethods';
/**
 * Options available when posting messages.
 *
 * @export
 * @interface PostMessageOptions
 */
export interface PostMessageOptions {
    /**
     * Do not wait for a response to the posted message.
     *
     * @type {boolean}
     * @memberOf PostMessageOptions
     */
    skipWait?: boolean;
    /**
     * Do not tag the name of the receiver in the beginning of the message.
     *
     * @type {boolean}
     * @memberOf PostMessageOptions
     */
    skipMention?: boolean;
    /**
     * The receiver id.
     *
     * @type {string}
     * @memberOf PostMessageOptions
     */
    receiver?: string;
}
export interface WaitForResponseOptions {
    /**
     * The receiver id.
     *
     * @type {string}
     * @memberOf WaitForResponseOptions
     */
    receiver?: string;
    normalizer?: (msg: any) => any;
    timeout?: number;
    skipNormalization?: boolean;
}
export interface UploadFileOptions {
    comment?: string;
    receiver?: string;
    skipWait?: boolean;
}
export declare class TestMethods {
    private platform;
    private config_;
    private defaultTimeout;
    constructor(platform: Platform, config_: Config);
    /**
     * Posts a message to the specified/default receiver.
     *
     * This methods waits for a response from the receiver, this
     * behaviour can be turned off by setting skipWait: true in the options.
     *
     * @param message string
     * @param opts PostMessageOptions
     */
    postMessage(message: string, opts?: PostMessageOptions): PromiseLike<any>;
    uploadFile(absPath: string, opts?: UploadFileOptions): PromiseLike<any>;
    sleep(time?: number): q.Promise<void>;
    getLastMessage(onlyString?: boolean, receiver?: string): PromiseLike<Message | string>;
    waitForResponseToBe(target: object | string, opts?: WaitForResponseOptions): q.Promise<{}>;
    waitForFileShare(receiver?: string, timeout?: number): q.Promise<any>;
    wait(method: (() => any | PromiseLike<any>) | PromiseLike<any>, message?: string, timeout?: number): q.Promise<any>;
    private waitForMessageAfterTs(timestamp, receiver?);
}
