"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const launcher_1 = require("../lib/launcher");
const chai_1 = require("chai");
describe('launcher', () => {
    it('The init exposed should be a function', () => {
        chai_1.expect(typeof launcher_1.init).to.equal('function');
    });
});
//# sourceMappingURL=launcher.tests.js.map